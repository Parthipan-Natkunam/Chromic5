#!/usr/bin/env python

from distutils.core import setup

setup(name='Chromic5',
      version='1.0',
      description='Color Palette Library',
      author='Parthipan Natkunam',
      packages=['chromic5'],
     )
